#include "Talent.h"

void Swimming::talantOut() {
    cout << "\tIt can SWIM" << endl;
}

void Dancing::talantOut() {
    cout << "\tIt can DANCE" << endl;
}

void Counting::talantOut() {
    cout << "\tIt can COUTE" << endl;
}