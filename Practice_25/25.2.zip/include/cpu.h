#pragma once

void compute();