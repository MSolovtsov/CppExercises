#pragma once
using namespace std;

static int byteBuffers[8];

void write(int& buf, int i);
void read(int& buf, int i);