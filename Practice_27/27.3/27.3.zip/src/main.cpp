#include "Head_of_the_company.h"

using namespace std;

int main() {
    cout << "\nTask #3\n  Simulation of the work of the company\n" << endl;

    Head_of_the_company* head = new Head_of_the_company();
    delete head;

    return 0;
}
